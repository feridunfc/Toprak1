"""
hfa-semantic/README.md

IRONCLAD Semantic Intelligence Layer — Production Foundation

## Overview

`hfa-semantic` is a sidecar intelligence layer for IRONCLAD. It provides:

1. **Distributed Truth Engine** (runtime)
   - Event correctness (dedup, ordering)
   - State management (bounded, deterministic)
   - Watermark-based lateness detection

2. **Reasoning** (future sprint)
   - DSL runtime
   - Temporal patterns
   - Graph inference

3. **Query Engine** (future sprint)
   - Graph + vector merge
   - Intersection-only results

4. **Policy Engine** (future sprint)
   - Bounded adaptation
   - HITL gates
   - Cooldown & bounds

5. **Memory Layer** (future sprint)
   - Validated outcomes
   - Relevance policies

6. **Observability**
   - Prometheus metrics
   - OpenTelemetry compatible

## Architecture

```
Event → Dedup → Watermark → StateStore-backed Runtime → Reasoning → Policy
```

### Core Principle

**Not a smart system. A distributed truth system.**

The semantic layer doesn't add AI. It fixes the single-node assumption
that undermines adaptive systems in production.

Three killer risks solved:
1. **Feedback Loop of Death** — permanent blindness from noise
2. **O(n²) State Explosion** — RAM/Redis bankruptcy
3. **Graph-Vector Schizophrenia** — agent gets contradictory data

## Components

### Runtime (Sprint R1)

| Module | Purpose | Status |
|--------|---------|--------|
| `state_store.py` | Abstract state backend | ✅ |
| `inmemory_state_store.py` | Dev/test backend | ✅ |
| `redis_state_store.py` | Production backend | ✅ |
| `dedup_store.py` | Event idempotency | ✅ |
| `watermark.py` | Event ordering | ✅ |
| `runtime_metrics.py` | Observability | ✅ |

### Reasoning (Sprint R4+)

| Module | Purpose | Status |
|--------|---------|--------|
| `dsl.py` | Temporal rule engine | 🔲 |
| `graph.py` | Neo4j inference | 🔲 |
| `patterns.py` | Causal rules | 🔲 |

### Query Engine (Sprint R5+)

| Module | Purpose | Status |
|--------|---------|--------|
| `graph_executor.py` | Neo4j queries | 🔲 |
| `vector_executor.py` | Qdrant similarity | 🔲 |
| `merge_engine.py` | Intersection merge | 🔲 |

### Policy Engine (Sprint R6+)

| Module | Purpose | Status |
|--------|---------|--------|
| `bounds.py` | Min/max enforcement | 🔲 |
| `cooldown.py` | Change rate limiting | 🔲 |
| `hitl_gate.py` | Human approval | 🔲 |

### Memory Layer (Sprint R7+)

| Module | Purpose | Status |
|--------|---------|--------|
| `outcome_writer.py` | Validated outcomes | 🔲 |
| `relevance.py` | Outcome ranking | 🔲 |

## Quick Start

### Development

```bash
cd hfa-semantic

# Install in editable mode with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Run with in-memory state store
export SEMANTIC_STATE_BACKEND=memory
python -m semantic_service
```

### Production

```bash
# Configure Redis backend
export SEMANTIC_STATE_BACKEND=redis
export SEMANTIC_REDIS_URL=redis://prod-redis:6379

# Run sidecar process
python -m semantic_service

# View metrics
curl http://localhost:8000/metrics
```

## Configuration

### Environment Variables

```bash
# Enable/disable semantic layer
SEMANTIC_ENABLED=true

# State storage backend
SEMANTIC_STATE_BACKEND=redis     # redis, memory
SEMANTIC_REDIS_URL=redis://...   # if redis backend

# Memory safety bounds
SEMANTIC_MAX_PARTITIONS_PER_RULE=10000
SEMANTIC_STATE_TTL_MS=3600000    # 1 hour

# Event handling
SEMANTIC_ALLOWED_LATENESS_MS=10000      # 10 seconds late max
SEMANTIC_LATE_EVENT_POLICY=drop         # drop, accept_with_correction, side_channel

# Dedup window
SEMANTIC_DEDUP_TTL_MS=3600000          # 1 hour retention

# Observability
SEMANTIC_METRICS_PORT=8000
SEMANTIC_LOG_LEVEL=INFO
```

## Production Guarantees

### Bounds
- ✅ Single partition state ≤ N MB (configurable)
- ✅ Max partitions per rule = capped (no state explosion)
- ✅ TTL eviction = automatic (no memory leak)

### Determinism
- ✅ No randomness in dedup
- ✅ No hidden state in watermark
- ✅ Idempotent operations
- ✅ Replay-safe

### Fault Tolerance
- ✅ Semantic failure = raw mode continues
- ✅ Redis degradation = graceful fallback
- ✅ No cascading failures
- ✅ Auto-restart with state recovery

### Observability
- ✅ Prometheus metrics
- ✅ OpenTelemetry compatible
- ✅ Event tracing
- ✅ Policy change audit

## Testing

### Unit Tests

```bash
pytest hfa-semantic/tests/test_runtime_foundation.py -v

# Specific test
pytest hfa-semantic/tests/test_runtime_foundation.py::test_inmemory_state_store_put_get -v
```

### Integration Tests

```bash
pytest hfa-semantic/tests/test_runtime_foundation.py -v -k integration
```

### Chaos Tests (Future)

```bash
pytest hfa-semantic/tests/chaos/ -v
# Tests for:
#   - Redis degradation
#   - Duplicate storm
#   - High-cardinality attack
#   - Policy runaway
```

## Integration with Core

See `INTEGRATION_GUIDE.md` for:
- ✅ How to integrate with scheduler (minimal, non-breaking)
- ✅ How to use in agent execution (optional)
- ✅ How to observe from the system (metrics)
- ❌ What files MUST NOT be modified

**TL;DR**: Semantic layer is optional, async, and gracefully degrades.

## Roadmap

| Sprint | Phase | Deliverable |
|--------|-------|-------------|
| R1 | Foundation | StateStore abstraction ✅ |
| R2 | Correctness | Dedup + Watermark ✅ |
| R3 | Observability | Metrics + Backpressure |
| R4 | Redis | Production-ready backend |
| R5 | Chaos | Redis failure + duplicate storm tests |
| S1 | Reasoning | DSL runtime + temporal rules |
| S2 | Query | Graph + vector merge |
| S3 | Memory | Validated outcome storage |
| S4 | Policy | Bounded adaptation |
| S5 | Production | Gate all of the above |

## Support

Issues or questions?

1. Check `INTEGRATION_GUIDE.md` (integration issues)
2. Check test suite for usage examples
3. Check `docs/` for architecture deep-dives
4. File issue with reproduction steps

## License

Part of IRONCLAD system. Same as parent project.
"""

