"""
hfa-semantic/tests/test_sprint_17_18.py

Sprint 17-18 Tests: Memory Decay + Cost-Aware Policy + Feedback Loop
"""

import pytest
from hfa_semantic.api.models import (
    OutcomeType,
    ValidatedOutcome,
    ValidatorType,
    PolicyDecision,
)
from hfa_semantic.memory.semantic_memory_v2 import SemanticMemoryV2
from hfa_semantic.memory.feedback_loop import FeedbackLoop
from hfa_semantic.policy.cost_model import CostModel
from hfa_semantic.policy.engine_v2 import PolicyEngineV2, PolicyEngineV2Config


# ═══════════════════════════════════════════════════════════════════════════
# SPRINT 17 TESTS: Memory Decay
# ═══════════════════════════════════════════════════════════════════════════


def test_memory_decay_reduces_old_weight() -> None:
    """Old outcomes have less weight than new ones (decay)."""
    memory = SemanticMemoryV2(half_life_ms=1000)

    # Add old outcome
    memory.append(
        ValidatedOutcome(
            event_id="old_event",
            outcome_type=OutcomeType.FALSE_POSITIVE,
            validated=True,
            validator=ValidatorType.RULE,
            confidence=1.0,
            timestamp_ms=0,
        )
    )

    # Add new outcome
    memory.append(
        ValidatedOutcome(
            event_id="new_event",
            outcome_type=OutcomeType.FALSE_POSITIVE,
            validated=True,
            validator=ValidatorType.RULE,
            confidence=1.0,
            timestamp_ms=900,
        )
    )

    # Get weighted outcomes at T=1000
    weighted_list = memory.weighted(now_ms=1000)
    weighted_dict = {x.outcome.event_id: x for x in weighted_list}

    # Should have both outcomes
    assert len(weighted_dict) == 2
    assert "old_event" in weighted_dict
    assert "new_event" in weighted_dict

    # Old outcome (age=1000ms) decay_weight should be ~0.5 (one half-life)
    # New outcome (age=100ms) decay_weight should be ~0.93
    assert weighted_dict["old_event"].decay_weight < weighted_dict["new_event"].decay_weight
    assert weighted_dict["old_event"].decay_weight < 0.6  # ~0.5


def test_memory_dedup_by_event_id() -> None:
    """Memory dedups by event_id (same event appended twice)."""
    memory = SemanticMemoryV2()

    outcome1 = ValidatedOutcome(
        event_id="e1",
        outcome_type=OutcomeType.SUCCESS,
        validated=True,
        validator=ValidatorType.RULE,
        confidence=0.8,
        timestamp_ms=1000,
    )

    outcome2 = ValidatedOutcome(
        event_id="e1",  # Same event_id
        outcome_type=OutcomeType.FAILURE,
        validated=True,
        validator=ValidatorType.RULE,
        confidence=0.9,
        timestamp_ms=2000,  # Later
    )

    # First append succeeds
    assert memory.append(outcome1) is True

    # Second append (same event_id) replaces
    assert memory.append(outcome2) is False

    # Check memory size
    assert memory.size == 1

    # Check it's the newer one
    assert memory.all()[0].outcome_type == OutcomeType.FAILURE


def test_memory_bounded_size() -> None:
    """Memory enforces max_items limit."""
    memory = SemanticMemoryV2(max_items=5)

    # Add 10 outcomes
    for i in range(10):
        outcome = ValidatedOutcome(
            event_id=f"e{i}",
            outcome_type=OutcomeType.SUCCESS,
            validated=True,
            validator=ValidatorType.RULE,
            confidence=0.9,
            timestamp_ms=1000 + i,
        )
        memory.append(outcome)

    # Should only have last 5
    assert memory.size == 5
    assert memory.utilization == 1.0


# ═══════════════════════════════════════════════════════════════════════════
# SPRINT 18 TESTS: Cost-Aware Policy + Feedback Loop
# ═══════════════════════════════════════════════════════════════════════════


def test_cost_model_false_negative_expensive() -> None:
    """False negatives weighted more than false positives in default model."""
    cost = CostModel()

    # Default: FN cost (5.0) > FP cost (1.0)
    assert cost.false_negative_cost > cost.false_positive_cost


def test_policy_engine_v2_raises_on_false_negative_pressure() -> None:
    """High false negative cost triggers threshold lowering (more sensitive)."""
    memory = SemanticMemoryV2()

    # Add 20 false negatives (high weighted FN pressure)
    for i in range(20):
        memory.append(
            ValidatedOutcome(
                event_id=f"fn-{i}",
                outcome_type=OutcomeType.FALSE_NEGATIVE,
                validated=True,
                validator=ValidatorType.RULE,
                confidence=0.95,
                timestamp_ms=1000 + i,
            )
        )

    engine = PolicyEngineV2()
    config = PolicyEngineV2Config(
        policy_key="detection_threshold",
        current_value=85.0,
        minimum=60.0,
        maximum=95.0,
        cooldown_ms=0,
        min_sample_size=10,
        min_avg_weighted_confidence=0.10,
        lower_step_abs=2.0,
    )

    decision = engine.evaluate(config, memory, now_ms=10_000)

    # Should propose lowering threshold (more sensitive)
    assert decision.proposed_value < config.current_value
    assert "false_negative_pressure" in decision.reason


def test_policy_engine_v2_lowers_on_false_positive_pressure() -> None:
    """High false positive cost triggers threshold raising (more strict)."""
    memory = SemanticMemoryV2()

    # Add 20 false positives
    for i in range(20):
        memory.append(
            ValidatedOutcome(
                event_id=f"fp-{i}",
                outcome_type=OutcomeType.FALSE_POSITIVE,
                validated=True,
                validator=ValidatorType.RULE,
                confidence=0.95,
                timestamp_ms=1000 + i,
            )
        )

    engine = PolicyEngineV2()
    config = PolicyEngineV2Config(
        policy_key="detection_threshold",
        current_value=50.0,
        minimum=40.0,
        maximum=95.0,
        cooldown_ms=0,
        min_sample_size=10,
        min_avg_weighted_confidence=0.10,
        raise_step_abs=2.0,
    )

    decision = engine.evaluate(config, memory, now_ms=10_000)

    # Should propose raising threshold (more strict)
    assert decision.proposed_value > config.current_value
    assert "false_positive_pressure" in decision.reason


def test_feedback_loop_tracks_decision() -> None:
    """Feedback loop links outcomes back to decisions."""
    loop = FeedbackLoop()

    # Create and register decision
    decision = PolicyDecision(
        decision_id="dec-001",
        policy_key="cpu_threshold",
        previous_value=80.0,
        proposed_value=82.0,
        approved=True,
        reason="cost_model:false_negative_pressure",
    )
    loop.register_decision(decision)

    # Create outcome linked to decision
    outcome = ValidatedOutcome(
        event_id="e1",
        decision_id="dec-001",
        outcome_type=OutcomeType.SUCCESS,
        validated=True,
        validator=ValidatorType.RULE,
        confidence=0.9,
        timestamp_ms=2000,
    )

    # Attach outcome to decision
    assert loop.attach_outcome(outcome) is True

    # Verify link exists
    links = loop.links_for_decision("dec-001")
    assert len(links) == 1
    assert links[0].event_id == "e1"


def test_feedback_loop_rejects_orphan_outcome() -> None:
    """Outcome with unknown decision_id is rejected."""
    loop = FeedbackLoop()

    outcome = ValidatedOutcome(
        event_id="e1",
        decision_id="unknown-dec",
        outcome_type=OutcomeType.SUCCESS,
        validated=True,
        validator=ValidatorType.RULE,
        confidence=0.9,
        timestamp_ms=1000,
    )

    # Should fail (decision not registered)
    assert loop.attach_outcome(outcome) is False


def test_policy_decision_has_unique_id() -> None:
    """Each policy decision gets unique decision_id."""
    memory = SemanticMemoryV2()

    # Add some outcomes
    for i in range(5):
        memory.append(
            ValidatedOutcome(
                event_id=f"e{i}",
                outcome_type=OutcomeType.FALSE_POSITIVE,
                validated=True,
                validator=ValidatorType.RULE,
                confidence=0.9,
                timestamp_ms=1000 + i,
            )
        )

    engine = PolicyEngineV2()
    config = PolicyEngineV2Config(
        policy_key="threshold",
        current_value=80.0,
        minimum=60.0,
        maximum=95.0,
        cooldown_ms=0,
        min_sample_size=3,
        min_avg_weighted_confidence=0.05,
    )

    decision1 = engine.evaluate(config, memory, now_ms=2000)
    decision2 = engine.evaluate(config, memory, now_ms=3000)

    # Each decision should have unique ID
    assert decision1.decision_id != decision2.decision_id
    assert len(decision1.decision_id) > 0
    assert len(decision2.decision_id) > 0

