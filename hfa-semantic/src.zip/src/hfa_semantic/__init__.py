"""
hfa-semantic/src/hfa_semantic/__init__.py

IRONCLAD Semantic Intelligence Layer — Main Package

This is a sidecar intelligence layer, NOT part of scheduler.

Provides:
  1. Distributed truth engine (runtime)
  2. Event correctness (dedup, ordering)
  3. Enrichment
  4. Reasoning (future)
  5. Query (future)
  6. Memory (future)
  7. Policy (future)
  8. Observability

CRITICAL RULE:
  * Scheduler must NOT call semantic synchronously
  * Semantic must be fully optional
  * All outputs must be ADDITIVE
"""

from .config import SemanticSettings, settings
from .runtime import (
    DedupStore,
    EvictionMetrics,
    EvictionPolicy,
    EvictionStrategy,
    InMemoryStateStore,
    LatenessPolicy,
    Partitioner,
    PartitionStrategy,
    RedisStateStore,
    RuntimeMetrics,
    RuntimeState,
    StateStore,
    Watermark,
)
from .runtime.factory import RuntimeFactory

__version__ = "0.1.0"

__all__ = [
    "SemanticSettings",
    "settings",
    "RuntimeFactory",
    "StateStore",
    "RuntimeState",
    "InMemoryStateStore",
    "RedisStateStore",
    "DedupStore",
    "Watermark",
    "LatenessPolicy",
    "RuntimeMetrics",
    "Partitioner",
    "PartitionStrategy",
    "EvictionPolicy",
    "EvictionStrategy",
    "EvictionMetrics",
]

