"""
hfa-semantic/src/hfa_semantic/config.py

IRONCLAD Semantic Layer — Configuration

All environment variables read through this class.
Direct os.environ.get() calls forbidden.
"""

from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class SemanticSettings(BaseSettings):
    """Semantic layer configuration."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    # Enable/disable
    SEMANTIC_ENABLED: bool = Field(
        default=True,
        description="Enable semantic layer",
    )

    # State backend
    SEMANTIC_STATE_BACKEND: str = Field(
        default="redis",
        description="State backend: redis, memory",
    )
    SEMANTIC_REDIS_URL: Optional[str] = Field(
        default=None,
        description="Redis connection URL",
    )

    # Memory safety bounds
    SEMANTIC_MAX_PARTITIONS_PER_RULE: int = Field(
        default=10_000,
        description="Max partitions per rule (prevents explosion)",
    )
    SEMANTIC_STATE_TTL_MS: int = Field(
        default=3_600_000,  # 1 hour
        description="State TTL in milliseconds",
    )

    # Event handling
    SEMANTIC_ALLOWED_LATENESS_MS: int = Field(
        default=10_000,
        description="How late (ms) is acceptable for events",
    )
    SEMANTIC_LATE_EVENT_POLICY: str = Field(
        default="drop",
        description="Late event policy: drop, accept_with_correction, side_channel",
    )

    # Dedup window
    SEMANTIC_DEDUP_TTL_MS: int = Field(
        default=3_600_000,
        description="Dedup entry TTL in milliseconds",
    )

    # Observability
    SEMANTIC_METRICS_PORT: int = Field(
        default=8000,
        description="Prometheus metrics port",
    )
    SEMANTIC_LOG_LEVEL: str = Field(
        default="INFO",
        description="Logging level",
    )

    # Partitioning
    SEMANTIC_PARTITION_STRATEGY: str = Field(
        default="entity_id",
        description="Partition strategy: entity_id, tenant_id, event_type, custom",
    )


settings = SemanticSettings()

