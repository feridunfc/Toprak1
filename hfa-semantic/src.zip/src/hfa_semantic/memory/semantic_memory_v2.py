"""
hfa-semantic/src/hfa_semantic/memory/semantic_memory_v2.py

Sprint 17 — Semantic Memory with Exponential Decay

CRITICAL UPGRADE:
  * Exponential time-based decay (old events matter less)
  * Dedup by event_id (no duplicate learning)
  * Weighted queries (decay_weight * confidence)
  * Sliding window (TTL enforcement)

Production guarantee:
  * Old noise doesn't distort recent learning
  * System forgets gracefully
  * Memory bias prevented
"""

from __future__ import annotations

from dataclasses import dataclass
from math import exp
from typing import Optional

from hfa_semantic.api.models import OutcomeType, ValidatedOutcome


@dataclass(slots=True, frozen=True)
class WeightedOutcome:
    """Outcome with decay weight applied."""
    outcome: ValidatedOutcome
    age_ms: int
    decay_weight: float
    weighted_confidence: float


class SemanticMemoryV2:
    """
    Memory with bounded storage, dedup, and exponential decay.
    
    CRITICAL:
      * Only validated outcomes stored
      * No duplicates (event_id based dedup)
      * Exponential decay weight applied on query
      * Old data influence decreases over time
    """

    def __init__(
        self,
        max_items: int = 10_000,
        half_life_ms: int = 24 * 60 * 60 * 1000,  # 24 hours
    ) -> None:
        self._max_items = max_items
        self._half_life_ms = half_life_ms
        
        # event_id -> outcome (dedup by event_id)
        self._items: dict[str, ValidatedOutcome] = {}
        self._size = 0

    def append(self, outcome: ValidatedOutcome) -> bool:
        """
        Append outcome (with dedup by event_id).
        
        Returns:
            True if appended, False if already existed
        """
        if not outcome.validated:
            return False
        
        is_new = outcome.event_id not in self._items
        
        if is_new and len(self._items) >= self._max_items:
            # Evict oldest by timestamp
            oldest_key = min(
                self._items.keys(),
                key=lambda k: self._items[k].timestamp_ms,
            )
            self._items.pop(oldest_key, None)
        
        self._items[outcome.event_id] = outcome
        return is_new

    def all(self) -> list[ValidatedOutcome]:
        """Return all stored outcomes."""
        return list(self._items.values())

    def weighted(self, now_ms: int) -> list[WeightedOutcome]:
        """
        Return all outcomes with decay weight applied.
        
        Decay formula: weight = exp(-ln(2) * age_ms / half_life_ms)
        """
        return [
            self._to_weighted(item, now_ms)
            for item in self._items.values()
        ]

    def weighted_by_decision(
        self, decision_id: str, now_ms: int
    ) -> list[WeightedOutcome]:
        """Get weighted outcomes for specific decision."""
        return [
            self._to_weighted(item, now_ms)
            for item in self._items.values()
            if item.decision_id == decision_id
        ]

    def weighted_by_type(
        self, outcome_type: OutcomeType, now_ms: int
    ) -> list[WeightedOutcome]:
        """Get weighted outcomes by type."""
        return [
            self._to_weighted(item, now_ms)
            for item in self._items.values()
            if item.outcome_type == outcome_type
        ]

    def _to_weighted(
        self, outcome: ValidatedOutcome, now_ms: int
    ) -> WeightedOutcome:
        """Apply decay weight to outcome."""
        age_ms = max(0, now_ms - outcome.timestamp_ms)
        decay_weight = self._exp_decay(age_ms)
        weighted_confidence = outcome.confidence * decay_weight
        
        return WeightedOutcome(
            outcome=outcome,
            age_ms=age_ms,
            decay_weight=decay_weight,
            weighted_confidence=weighted_confidence,
        )

    def _exp_decay(self, age_ms: int) -> float:
        """
        Exponential decay based on half-life.
        
        Formula: weight = exp(-ln(2) * age_ms / half_life_ms)
        
        At age = half_life: weight = 0.5
        At age = 2 * half_life: weight = 0.25
        """
        if age_ms <= 0:
            return 1.0
        
        # ln(2) ≈ 0.69314718056
        return exp(-0.69314718056 * age_ms / self._half_life_ms)

    @property
    def size(self) -> int:
        """Current memory size."""
        return len(self._items)

    @property
    def utilization(self) -> float:
        """Memory utilization (0.0-1.0)."""
        return self.size / self._max_items if self._max_items > 0 else 0.0

