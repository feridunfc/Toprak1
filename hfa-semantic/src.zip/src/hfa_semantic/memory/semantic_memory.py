"""
hfa-semantic/src/hfa_semantic/memory/semantic_memory.py

Sprint 15 — In-Memory Semantic Storage

Simple bounded storage for validated outcomes.
Replace with Redis/Postgres/Vector DB for production.
"""

from __future__ import annotations

from collections import deque
from hfa_semantic.api.models import ValidatedOutcome, OutcomeType


class SemanticMemory:
    """
    Bounded in-memory storage for validated outcomes.
    
    CRITICAL: Only validated outcomes are stored here.
    Raw outcomes are rejected.
    """

    def __init__(self, max_items: int = 10_000) -> None:
        self._items: deque[ValidatedOutcome] = deque(maxlen=max_items)
        self._max_items = max_items

    def append(self, outcome: ValidatedOutcome) -> None:
        """Store validated outcome."""
        if not outcome.validated:
            raise ValueError("Only validated outcomes can be stored")
        self._items.append(outcome)

    def all(self) -> list[ValidatedOutcome]:
        """Return all stored outcomes."""
        return list(self._items)

    def by_type(self, outcome_type: OutcomeType) -> list[ValidatedOutcome]:
        """Filter outcomes by type."""
        return [item for item in self._items if item.outcome_type == outcome_type]

    def by_event_id(self, event_id: str) -> list[ValidatedOutcome]:
        """Get outcomes for specific event."""
        return [item for item in self._items if item.event_id == event_id]

    def recent(self, count: int = 100) -> list[ValidatedOutcome]:
        """Get N most recent outcomes."""
        items = list(self._items)
        return items[-count:] if len(items) > count else items

    @property
    def size(self) -> int:
        """Current memory size."""
        return len(self._items)

    @property
    def capacity(self) -> int:
        """Max capacity."""
        return self._max_items

    @property
    def utilization(self) -> float:
        """Current utilization (0.0-1.0)."""
        return self.size / self.capacity if self.capacity > 0 else 0.0

