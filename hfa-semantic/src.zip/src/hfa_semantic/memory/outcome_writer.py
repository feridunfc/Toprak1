"""
hfa-semantic/src/hfa_semantic/memory/outcome_writer.py

Sprint 15 — Memory Write Gate

Filter before memory write.
"""

from __future__ import annotations

from hfa_semantic.api.models import ValidatedOutcome
from hfa_semantic.memory.relevance_policy import retain
from hfa_semantic.memory.semantic_memory import SemanticMemory


class OutcomeWriter:
    """
    Gate that decides what outcomes get written to memory.
    """

    def __init__(self, memory: SemanticMemory, min_confidence: float = 0.70) -> None:
        self._memory = memory
        self._min_confidence = min_confidence
        self._write_count = 0
        self._reject_count = 0

    def write(self, outcome: ValidatedOutcome) -> bool:
        """
        Try to write outcome to memory.
        
        Returns:
            True if written, False if rejected
        """
        if not retain(outcome, self._min_confidence):
            self._reject_count += 1
            return False

        self._memory.append(outcome)
        self._write_count += 1
        return True

    @property
    def stats(self) -> dict:
        return {
            "written": self._write_count,
            "rejected": self._reject_count,
            "memory_size": self._memory.size,
            "memory_utilization": self._memory.utilization,
        }

