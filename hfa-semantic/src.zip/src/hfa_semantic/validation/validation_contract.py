"""
hfa-semantic/src/hfa_semantic/validation/validation_contract.py

Sprint 15 — Validation Decision Contract
"""

from __future__ import annotations

from dataclasses import dataclass
from hfa_semantic.api.models import ValidatorType


@dataclass(slots=True, frozen=True)
class ValidationDecision:
    """Validation gate outcome."""
    validated: bool
    validator: ValidatorType
    confidence: float
    notes: str = ""

