"""
hfa-semantic/src/hfa_semantic/validation/outcome_validator.py

Sprint 15 — Outcome Validation Engine

Three validation paths:
1. Rule-based (high confidence → immediate validation)
2. Delayed signal (false pos/neg → time-delayed validation)
3. Human review (low confidence / ambiguous → HITL escalation)
"""

from __future__ import annotations

from hfa_semantic.api.models import RawOutcome, OutcomeType, ValidatorType
from hfa_semantic.validation.delayed_signal import delayed_truth_available
from hfa_semantic.validation.human_review import HumanReviewAdapter, HumanReviewRequest
from hfa_semantic.validation.validation_contract import ValidationDecision


class OutcomeValidator:
    """
    Validates execution outcomes before they enter memory/policy.
    
    CRITICAL: Unvalidated outcomes are discarded. Only validated outcomes
    feed back into semantic memory and policy engine.
    """

    def __init__(
        self,
        human_review: HumanReviewAdapter | None = None,
        min_confidence: float = 0.80,
        delayed_signal_ms: int = 300_000,
    ) -> None:
        self._human_review = human_review or HumanReviewAdapter()
        self._min_confidence = min_confidence
        self._delayed_signal_ms = delayed_signal_ms
        
        # Metrics
        self._validated_count = 0
        self._human_review_count = 0
        self._delayed_signal_count = 0

    def validate(self, outcome: RawOutcome, now_ms: int) -> ValidationDecision:
        """
        Validate outcome through gates.
        
        Args:
            outcome: Raw execution result
            now_ms: Current timestamp (for age calculation)
            
        Returns:
            ValidationDecision (validated + validator type)
        """
        age_ms = max(0, now_ms - outcome.timestamp_ms)

        # GATE 1: High-confidence success/failure → immediate rule validation
        if (
            outcome.outcome_type in {OutcomeType.SUCCESS, OutcomeType.FAILURE}
            and outcome.confidence >= self._min_confidence
        ):
            self._validated_count += 1
            return ValidationDecision(
                validated=True,
                validator=ValidatorType.RULE,
                confidence=outcome.confidence,
                notes="rule_validated_immediately",
            )

        # GATE 2: False positive/negative → delayed truth window
        if outcome.outcome_type in {OutcomeType.FALSE_POSITIVE, OutcomeType.FALSE_NEGATIVE}:
            if delayed_truth_available(age_ms, self._delayed_signal_ms):
                self._delayed_signal_count += 1
                return ValidationDecision(
                    validated=True,
                    validator=ValidatorType.DELAYED_SIGNAL,
                    confidence=outcome.confidence,
                    notes=f"validated_by_delayed_signal_after_{age_ms}ms",
                )

        # GATE 3: Low-confidence or ambiguous → escalate to human
        self._human_review_count += 1
        self._human_review.request_review(
            HumanReviewRequest(
                subject=f"Outcome validation required: {outcome.event_id}",
                details=(
                    f"type={outcome.outcome_type.value} "
                    f"confidence={outcome.confidence:.2f} "
                    f"age_ms={age_ms} "
                    f"notes={outcome.notes}"
                ),
                severity="high" if outcome.confidence < 0.50 else "normal",
            )
        )
        
        return ValidationDecision(
            validated=False,
            validator=ValidatorType.HUMAN,
            confidence=outcome.confidence,
            notes="human_review_requested",
        )

    @property
    def stats(self) -> dict:
        """Return validation statistics."""
        return {
            "validated_total": self._validated_count,
            "delayed_signal": self._delayed_signal_count,
            "human_review_escalated": self._human_review_count,
        }

