"""
hfa-semantic/src/hfa_semantic/validation/delayed_signal.py

Sprint 15 — Delayed Truth Window

False positive/negative validation with time-delayed confirmation.
"""

from __future__ import annotations


def delayed_truth_available(
    outcome_age_ms: int,
    min_delay_ms: int = 300_000,
) -> bool:
    """
    Check if enough time has passed for delayed truth validation.
    
    False positive/negative outcomes are validated only after waiting
    N milliseconds to see if the original signal corrects itself.
    """
    return outcome_age_ms >= min_delay_ms

