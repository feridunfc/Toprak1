"""
hfa-semantic/src/hfa_semantic/api/models.py

IRONCLAD Sprint 17-18 — Core Data Models (with decision linkage)

Updated: decision_id for closed-loop feedback
"""

from __future__ import annotations

from enum import Enum
from pydantic import BaseModel, Field
from typing import Optional, List


class OutcomeType(str, Enum):
    """Execution outcome classification."""
    SUCCESS = "success"
    FAILURE = "failure"
    FALSE_POSITIVE = "false_positive"
    FALSE_NEGATIVE = "false_negative"
    RESOLVED = "resolved"


class ValidatorType(str, Enum):
    """Which validator confirmed outcome?"""
    RULE = "rule"
    HUMAN = "human"
    DELAYED_SIGNAL = "delayed_signal"


class RawOutcome(BaseModel):
    """Unvalidated execution result (with decision link)."""
    event_id: str
    lineage_run_id: Optional[str] = None
    decision_id: Optional[str] = None  # Link to policy decision (if applicable)
    outcome_type: OutcomeType
    confidence: float = Field(ge=0.0, le=1.0)
    timestamp_ms: int
    notes: str = ""


class ValidatedOutcome(BaseModel):
    """Outcome that passed validation gates (with decision link)."""
    event_id: str
    lineage_run_id: Optional[str] = None
    decision_id: Optional[str] = None  # Link to policy decision (if applicable)
    outcome_type: OutcomeType
    validated: bool
    validator: ValidatorType
    confidence: float = Field(ge=0.0, le=1.0)
    timestamp_ms: int
    notes: str = ""


class PolicyDecision(BaseModel):
    """Policy engine proposal with unique decision ID for feedback tracking."""
    decision_id: str  # UUID - tracks this decision through feedback loop
    policy_key: str
    previous_value: float
    proposed_value: float
    approved: bool = False
    reason: str = ""
    requires_hitl: bool = False
    cooldown_applied: bool = False
    tags: List[str] = Field(default_factory=list)



