"""
hfa-semantic/src/hfa_semantic/runtime/eviction.py

IRONCLAD Sprint R1 — State Eviction Policy

CRITICAL GUARD:
  * Max partitions per rule (no unbounded growth)
  * TTL + LRU combination
  * Watermark-driven cleanup

Strategies:
  * TTL only: expire by age
  * LRU: evict least recently used
  * Watermark: evict beyond event window
  * Hybrid: combine above
"""

from enum import Enum
from typing import Optional


class EvictionStrategy(str, Enum):
    """State eviction strategies."""
    TTL_ONLY = "ttl_only"
    LRU = "lru"
    WATERMARK = "watermark"
    HYBRID = "hybrid"


class EvictionPolicy:
    """
    State eviction configuration with partition pressure monitoring.

    Prevents unbounded state growth.
    
    CRITICAL GUARDS:
      * max_partitions_per_rule (hard limit)
      * adaptive eviction when approaching limit
      * pressure signals for backpressure
    """

    def __init__(
        self,
        strategy: EvictionStrategy = EvictionStrategy.HYBRID,
        max_partitions_per_rule: int = 10_000,
        ttl_ms: int = 3_600_000,  # 1 hour
        watermark_window_ms: int = 3_600_000,  # 1 hour
        partition_pressure_threshold: float = 0.8,  # Trigger at 80%
    ):
        self._strategy = strategy
        self._max_partitions = max_partitions_per_rule
        self._ttl_ms = ttl_ms
        self._watermark_window_ms = watermark_window_ms
        self._pressure_threshold = partition_pressure_threshold
        
        # Metrics
        self._current_partition_count = 0
        self._last_pressure_signal = False

    @property
    def strategy(self) -> EvictionStrategy:
        return self._strategy

    @property
    def max_partitions(self) -> int:
        return self._max_partitions

    @property
    def ttl_ms(self) -> int:
        return self._ttl_ms

    @property
    def watermark_window_ms(self) -> int:
        return self._watermark_window_ms

    def update_partition_count(self, count: int) -> None:
        """Update current partition count (call after each query)."""
        self._current_partition_count = count

    @property
    def partition_pressure(self) -> float:
        """Return pressure 0.0-1.0 (0=empty, 1.0=full)."""
        if self._max_partitions == 0:
            return 0.0
        return min(1.0, self._current_partition_count / self._max_partitions)

    @property
    def under_pressure(self) -> bool:
        """Return True if partition count approaching limit."""
        pressure = self.partition_pressure
        under = pressure >= self._pressure_threshold
        
        # Signal change only on transition
        if under != self._last_pressure_signal:
            self._last_pressure_signal = under
            return True  # Signal triggered
        
        return False

    def aggressive_eviction_needed(self) -> bool:
        """Return True if we need to evict more aggressively."""
        return self.partition_pressure >= 0.95  # 95% full = emergency

    def should_evict_by_ttl(self, last_update_ms: float, now_ms: float) -> bool:
        """Check if state should be evicted by TTL."""
        if self._strategy in (EvictionStrategy.TTL_ONLY, EvictionStrategy.HYBRID):
            return now_ms - last_update_ms > self._ttl_ms
        return False

    def should_evict_by_watermark(
        self, event_time_ms: float, watermark_ms: float
    ) -> bool:
        """Check if state should be evicted by watermark."""
        if self._strategy in (EvictionStrategy.WATERMARK, EvictionStrategy.HYBRID):
            return watermark_ms - event_time_ms > self._watermark_window_ms
        return False

    def get_eviction_batch_size(self) -> int:
        """Return how many partitions to evict in one batch."""
        if self.aggressive_eviction_needed():
            # Emergency: evict 20% of max
            return max(10, int(self._max_partitions * 0.2))
        elif self.under_pressure:
            # Under pressure: evict 10% of max
            return max(5, int(self._max_partitions * 0.1))
        else:
            # Normal: evict 1% of max
            return max(1, int(self._max_partitions * 0.01))


class EvictionMetrics:
    """Track eviction statistics."""

    def __init__(self):
        self._total_evicted = 0
        self._ttl_evictions = 0
        self._watermark_evictions = 0
        self._lru_evictions = 0

    def record_ttl_eviction(self, count: int = 1) -> None:
        self._ttl_evictions += count
        self._total_evicted += count

    def record_watermark_eviction(self, count: int = 1) -> None:
        self._watermark_evictions += count
        self._total_evicted += count

    def record_lru_eviction(self, count: int = 1) -> None:
        self._lru_evictions += count
        self._total_evicted += count

    @property
    def total_evicted(self) -> int:
        return self._total_evicted

    @property
    def ttl_evictions(self) -> int:
        return self._ttl_evictions

    @property
    def watermark_evictions(self) -> int:
        return self._watermark_evictions

    @property
    def lru_evictions(self) -> int:
        return self._lru_evictions

