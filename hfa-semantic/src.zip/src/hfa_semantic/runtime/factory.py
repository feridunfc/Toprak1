"""
hfa-semantic/src/hfa_semantic/runtime/factory.py

IRONCLAD — Runtime Factory

Creates appropriate runtime components based on configuration.
"""

import redis.asyncio as redis

from hfa_semantic.config import settings

from .dedup_store import DedupStore
from .eviction import EvictionPolicy, EvictionStrategy
from .inmemory_state_store import InMemoryStateStore
from .redis_state_store import RedisStateStore
from .runtime_metrics import RuntimeMetrics
from .state_store import StateStore
from .watermark import LatenessPolicy, Watermark


class RuntimeFactory:
    """Factory for creating runtime components."""

    @staticmethod
    async def create_state_store() -> StateStore:
        """
        Create state store based on configuration.

        Returns:
            StateStore instance (in-memory or Redis)
        """
        backend = settings.SEMANTIC_STATE_BACKEND.lower()

        if backend == "memory":
            return InMemoryStateStore()

        elif backend == "redis":
            redis_url = settings.SEMANTIC_REDIS_URL
            if not redis_url:
                raise ValueError("SEMANTIC_REDIS_URL required for Redis backend")

            client = redis.from_url(redis_url, decode_responses=True)
            # Test connection
            await client.ping()
            return RedisStateStore(client)

        else:
            raise ValueError(f"Unknown state backend: {backend}")

    @staticmethod
    async def create_dedup_store() -> DedupStore:
        """Create dedup store (always Redis-backed)."""
        redis_url = settings.SEMANTIC_REDIS_URL
        if not redis_url:
            raise ValueError("SEMANTIC_REDIS_URL required for DedupStore")

        client = redis.from_url(redis_url, decode_responses=True)
        await client.ping()
        return DedupStore(client)

    @staticmethod
    def create_watermark() -> Watermark:
        """Create watermark."""
        return Watermark(allowed_lateness_ms=settings.SEMANTIC_ALLOWED_LATENESS_MS)

    @staticmethod
    def create_eviction_policy() -> EvictionPolicy:
        """Create eviction policy."""
        return EvictionPolicy(
            strategy=EvictionStrategy.HYBRID,
            max_partitions_per_rule=settings.SEMANTIC_MAX_PARTITIONS_PER_RULE,
            ttl_ms=settings.SEMANTIC_STATE_TTL_MS,
            watermark_window_ms=settings.SEMANTIC_STATE_TTL_MS,
        )

    @staticmethod
    def create_metrics() -> RuntimeMetrics:
        """Create metrics."""
        return RuntimeMetrics()

    @staticmethod
    async def create_all() -> dict:
        """
        Create all runtime components.

        Returns:
            Dictionary of components.
        """
        return {
            "state_store": await RuntimeFactory.create_state_store(),
            "dedup_store": await RuntimeFactory.create_dedup_store(),
            "watermark": RuntimeFactory.create_watermark(),
            "eviction_policy": RuntimeFactory.create_eviction_policy(),
            "metrics": RuntimeFactory.create_metrics(),
        }

