"""
hfa-semantic/src/hfa_semantic/runtime/watermark.py

IRONCLAD Sprint R2 — Watermark & Event Ordering

CRITICAL:
  * Event ordering guarantee
  * Lateness detection
  * Deterministic handling

Concepts:
  * event_time: when event occurred
  * processing_time: when system sees it
  * watermark: latest event_time processed
  * allowed_lateness_ms: how late is acceptable

Default behavior:
  * allowed_lateness_ms = 10_000 (10 seconds)
  * Late events dropped (can be overridden)
"""

import json
import time
from enum import Enum
from typing import Optional

import redis.asyncio as redis


class LatenessPolicy(str, Enum):
    """
    How to handle events that arrive late.

    DROP: ignore (default, safe)
    ACCEPT_WITH_CORRECTION: process and retry matching
    SIDE_CHANNEL: route to repair queue for batch processing
    """
    DROP = "drop"
    ACCEPT_WITH_CORRECTION = "accept_with_correction"
    SIDE_CHANNEL = "side_channel"


class Watermark:
    """
    Distributed watermark tracking with optional Redis backend.
    
    Watermark = max(event_time) seen so far.
    Late event = event_time < watermark - allowed_lateness_ms
    
    When Redis is provided, watermark is globally consistent across workers.
    """

    def __init__(
        self,
        allowed_lateness_ms: int = 10_000,
        redis_client: Optional[redis.Redis] = None,
        rule_id: Optional[str] = None,
        namespace: str = "semantic:watermark",
    ):
        self._allowed_lateness_ms = allowed_lateness_ms
        self._redis = redis_client
        self._rule_id = rule_id
        self._namespace = namespace
        
        # Local cache for fast reads (will sync with Redis if available)
        self._watermark_ms = 0.0
        self._late_count = 0
        self._on_time_count = 0

    def _make_key(self) -> str:
        """Redis key for watermark state."""
        if not self._rule_id:
            raise ValueError("rule_id required for Redis-backed watermark")
        return f"{self._namespace}:{self._rule_id}"

    async def _sync_from_redis(self) -> None:
        """Load watermark state from Redis."""
        if not self._redis or not self._rule_id:
            return

        key = self._make_key()
        data = await self._redis.get(key)
        if data:
            try:
                obj = json.loads(data)
                self._watermark_ms = float(obj.get("watermark_ms", 0))
                self._late_count = int(obj.get("late_count", 0))
                self._on_time_count = int(obj.get("on_time_count", 0))
            except (json.JSONDecodeError, ValueError):
                pass

    async def _sync_to_redis(self) -> None:
        """Persist watermark state to Redis."""
        if not self._redis or not self._rule_id:
            return

        key = self._make_key()
        data = json.dumps({
            "watermark_ms": self._watermark_ms,
            "late_count": self._late_count,
            "on_time_count": self._on_time_count,
        })
        
        # Use atomic increment if available
        await self._redis.set(key, data, ex=86400)  # 24h TTL

    async def observe(self, event_time_ms: float) -> tuple[bool, bool]:
        """
        Observe an event and update watermark (Redis-consistent).

        Returns:
            (is_late, should_accept)
        """
        # Sync from Redis first (if available)
        await self._sync_from_redis()
        
        now_ms = time.time() * 1000.0

        # If event_time is in future, clip to now
        if event_time_ms > now_ms:
            event_time_ms = now_ms

        # Check if late relative to watermark
        is_late = event_time_ms < self._watermark_ms - self._allowed_lateness_ms

        if is_late:
            self._late_count += 1
        else:
            self._on_time_count += 1
            # Update watermark only for on-time events
            self._watermark_ms = max(self._watermark_ms, event_time_ms)

        # Sync back to Redis
        await self._sync_to_redis()

        return is_late, not is_late

    async def should_accept(self, event_time_ms: float, policy: LatenessPolicy) -> bool:
        """Determine if event should be accepted based on policy."""
        is_late, _ = await self.observe(event_time_ms)

        if not is_late:
            return True

        if policy == LatenessPolicy.DROP:
            return False
        elif policy == LatenessPolicy.ACCEPT_WITH_CORRECTION:
            return True
        elif policy == LatenessPolicy.SIDE_CHANNEL:
            return False
        else:
            return False

    @property
    def watermark_ms(self) -> float:
        return self._watermark_ms

    @property
    def late_count(self) -> int:
        return self._late_count

    @property
    def on_time_count(self) -> int:
        return self._on_time_count

    def reset(self) -> None:
        """Reset watermark (for testing)."""
        self._watermark_ms = 0.0
        self._late_count = 0
        self._on_time_count = 0

