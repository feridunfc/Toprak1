"""
hfa-semantic/src/hfa_semantic/runtime/eviction_v2.py

IRONCLAD v6 — Batch Eviction Engine with Backpressure

CRITICAL FIX from v1:
  * Bulk delete (not one-by-one)
  * Backpressure signals
  * Adaptive batch sizing
  * Lua batch eviction
"""

from typing import Optional
import redis.asyncio as redis
from .lua_scripts import LuaScripts


class EvictionV2:
    """
    Production eviction with batch delete and backpressure.
    """

    def __init__(
        self,
        max_partitions_per_rule: int = 10_000,
        ttl_ms: int = 3_600_000,
        pressure_threshold: float = 0.80,
    ):
        self._max_partitions = max_partitions_per_rule
        self._ttl_ms = ttl_ms
        self._pressure_threshold = pressure_threshold
        
        # Current state
        self._current_partitions = 0
        self._under_pressure = False

    def update_partition_count(self, count: int) -> None:
        """Update current partition count."""
        self._current_partitions = count
        old_pressure = self._under_pressure
        self._under_pressure = self.pressure_ratio >= self._pressure_threshold
        
        # Signal transition only
        if self._under_pressure != old_pressure:
            self._pressure_changed = True

    @property
    def pressure_ratio(self) -> float:
        """Return 0.0-1.0 pressure ratio."""
        if self._max_partitions == 0:
            return 0.0
        return min(1.0, self._current_partitions / self._max_partitions)

    @property
    def is_under_pressure(self) -> bool:
        """Return True if pressure >= threshold."""
        return self.pressure_ratio >= self._pressure_threshold

    @property
    def is_critical(self) -> bool:
        """Return True if pressure >= 95% (emergency)."""
        return self.pressure_ratio >= 0.95

    def get_adaptive_batch_size(self) -> int:
        """
        Return batch size for eviction based on pressure.
        
        Normal (< 80%): evict 1% of max
        Pressure (80-95%): evict 10% of max
        Critical (>= 95%): evict 20% of max
        """
        pressure = self.pressure_ratio
        
        if pressure >= 0.95:
            # Emergency: 20% of max
            return max(100, int(self._max_partitions * 0.20))
        elif pressure >= 0.80:
            # Pressure: 10% of max
            return max(50, int(self._max_partitions * 0.10))
        else:
            # Normal: 1% of max
            return max(10, int(self._max_partitions * 0.01))

    async def evict_bulk(
        self,
        redis_client: redis.Redis,
        rule_id: str,
        max_partitions: Optional[int] = None,
    ) -> int:
        """
        Bulk evict oldest partitions (via Lua).
        
        Args:
            redis_client: Redis connection
            rule_id: Rule to evict from
            max_partitions: Max partitions allowed (default: self._max_partitions)
            
        Returns:
            Number of partitions evicted
        """
        if max_partitions is None:
            max_partitions = self._max_partitions

        zset_key = f"semantic:state:zset:{rule_id}"
        state_prefix = f"semantic:state:{rule_id}:"

        # Get current count
        count = await redis_client.zcard(zset_key)

        if count <= max_partitions:
            return 0

        # Calculate how many to evict
        to_evict = count - max_partitions

        # Use adaptive batch size if evicting a lot
        batch_size = min(to_evict, self.get_adaptive_batch_size())

        try:
            # Lua batch eviction
            evicted = await redis_client.eval(
                LuaScripts.EVICT_BULK,
                1,  # num keys
                zset_key,
                state_prefix,
                batch_size,
            )
            return int(evicted)
        except Exception:
            # Fallback: manual batch delete
            oldest = await redis_client.zrange(zset_key, 0, batch_size - 1)
            
            if not oldest:
                return 0

            # Delete state keys
            for partition_bytes in oldest:
                partition = (
                    partition_bytes.decode()
                    if isinstance(partition_bytes, bytes)
                    else partition_bytes
                )
                state_key = f"{state_prefix}{partition}"
                await redis_client.delete(state_key)

            # Remove from zset
            await redis_client.zrem(zset_key, *oldest)

            return len(oldest)


class BackpressureController:
    """
    Signals system when eviction can't keep up.
    """

    def __init__(self, eviction: EvictionV2):
        self._eviction = eviction
        self._backpressure_active = False

    async def check_and_signal(self) -> tuple[bool, str]:
        """
        Check if system is under backpressure.
        
        Returns:
            (is_backpressured, reason)
        """
        if self._eviction.is_critical:
            self._backpressure_active = True
            return True, "CRITICAL: partition count >95% max"
        elif self._eviction.is_under_pressure:
            self._backpressure_active = True
            return True, "WARN: partition count >80% max"
        else:
            self._backpressure_active = False
            return False, "OK"

    def should_accept_event(self) -> bool:
        """
        Return False to drop incoming events if backpressure active.
        """
        return not self._backpressure_active

