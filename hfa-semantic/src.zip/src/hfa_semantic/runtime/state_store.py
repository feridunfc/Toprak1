"""
hfa-semantic/src/hfa_semantic/runtime/state_store.py

IRONCLAD Sprint R1 — State Store Abstraction

The StateStore is the CORE of the semantic runtime.
It must support:
  * In-memory (dev/test)
  * Redis (prod)
  * Optional future: RocksDB, Kafka Streams state

CRITICAL:
  * Deterministic
  * Bounded memory
  * TTL eviction
  * Partition cardinality control

This is NOT part of scheduler — purely semantic layer.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class RuntimeState:
    """Semantic runtime state for a single (rule, partition) pair."""
    rule_id: str
    partition: str
    state: Dict[str, Any]
    event_count: int = 0
    last_update_ms: float = 0.0
    ttl_ms: int = 0  # milliseconds


class StateStore(ABC):
    """
    Abstract interface for semantic runtime state storage.

    Implementations must be:
      * Deterministic (no randomness)
      * Atomic for single (rule, partition)
      * TTL-aware
      * Partition cardinality bounded
    """

    @abstractmethod
    async def get(self, rule_id: str, partition: str) -> Optional[RuntimeState]:
        """
        Retrieve runtime state for (rule, partition).
        Return None if not found or expired.
        """
        pass

    @abstractmethod
    async def put(
        self, rule_id: str, partition: str, state: Dict[str, Any], ttl_ms: int
    ) -> None:
        """
        Store runtime state for (rule, partition) with TTL.
        Must be atomic.
        """
        pass

    @abstractmethod
    async def delete(self, rule_id: str, partition: str) -> None:
        """Delete state for (rule, partition)."""
        pass

    @abstractmethod
    async def evict(self, rule_id: str, max_partitions: int) -> int:
        """
        Evict oldest partitions if count exceeds max_partitions.
        Return count of evicted partitions.

        CRITICAL for memory safety.
        """
        pass

    @abstractmethod
    async def list_partitions(self, rule_id: str) -> list[str]:
        """List all active partitions for a rule."""
        pass

    @abstractmethod
    async def close(self) -> None:
        """Gracefully close the store."""
        pass

