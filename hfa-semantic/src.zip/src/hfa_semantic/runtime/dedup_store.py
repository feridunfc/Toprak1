"""
hfa-semantic/src/hfa_semantic/runtime/dedup_store.py

IRONCLAD Sprint R2 — Dedup Store (Event Idempotency)

CRITICAL:
  * Duplicate events must NOT produce duplicate matches
  * Event_id based TTL tracking
  * Deterministic collision handling

Problem solved:
  * Retry storms
  * Network duplicates
  * Batch reprocessing

Mechanism:
  event → check dedup
    if exists → DROP
    else → PROCESS + STORE

Key format:
  semantic:dedup:{event_id}
"""

import json
import time
from typing import Optional

import redis.asyncio as redis


class DedupStore:
    """Event deduplication store backed by Redis."""

    def __init__(self, redis_client: redis.Redis, namespace: str = "semantic:dedup"):
        self._redis = redis_client
        self._namespace = namespace

    def _make_key(self, event_id: str) -> str:
        return f"{self._namespace}:{event_id}"

    async def try_accept(
        self, event_id: str, event_time_ms: float, ttl_ms: int = 3_600_000
    ) -> bool:
        """
        CRITICAL: Single atomic dedup check + mark (NO RACE CONDITION).
        
        Uses Redis SET ... NX EX for atomic first-writer-wins semantics.
        Check and mark happen in ONE atomic operation.
        
        Args:
            event_id: Unique event identifier
            event_time_ms: Event timestamp (milliseconds)
            ttl_ms: Time-to-live for dedup entry
            
        Returns:
            True if ACCEPTED (we won, first time seeing this event_id)
            False if DUPLICATE (event_id already processed by another worker)
            
        GUARANTEE:
            Only ONE worker globally will get True for same event_id.
            All others get False.
            No data loss on concurrent calls.
        """
        key = self._make_key(event_id)
        now_ms = time.time() * 1000.0
        
        data = json.dumps({
            "event_id": event_id,
            "accepted_at": now_ms,
            "event_time": event_time_ms,
        })

        ttl_sec = int((ttl_ms + 999) / 1000)
        
        # ATOMIC: Set if not exists + TTL in ONE operation
        # Returns value if set (we won), None if already exists (duplicate)
        success = await self._redis.set(
            key,
            data,
            ex=ttl_sec,
            nx=True  # Only set if doesn't exist
        )
        
        return success is not None


    async def is_duplicate(self, event_id: str) -> bool:
        """
        Check if event_id was already processed (distributed-safe).
        
        Uses Redis GET for consistency across workers.
        Returns True if duplicate, False if new.
        
        CRITICAL: This is globally atomic across all workers.
        """
        key = self._make_key(event_id)
        exists = await self._redis.exists(key)
        return exists > 0

    async def mark_processed(
        self, event_id: str, event_time_ms: float, ttl_ms: int = 3_600_000
    ) -> bool:
        """
        Mark event as processed (SETNX atomic).
        
        Args:
            event_id: Unique event identifier
            event_time_ms: Event timestamp (milliseconds)
            ttl_ms: Time-to-live for dedup entry
            
        Returns:
            True if we won the race (first to mark), False if duplicate already existed
            
        CRITICAL: Uses SETNX for atomic "first writer wins" semantics.
        No two workers can process same event_id.
        """
        key = self._make_key(event_id)
        data = json.dumps({
            "event_id": event_id,
            "processed_at": time.time() * 1000.0,
            "event_time": event_time_ms,
        })

        ttl_sec = int((ttl_ms + 999) / 1000)
        
        # CRITICAL: SETNX ensures only first writer succeeds
        # Other workers trying same event_id get False
        success = await self._redis.set(
            key, 
            data, 
            ex=ttl_sec,
            nx=True  # Only set if not exists (SETNX)
        )
        
        return success is not None  # True if we set it, False if already existed

    async def get_entry(self, event_id: str) -> Optional[dict]:
        """Retrieve dedup entry if exists."""
        key = self._make_key(event_id)
        data = await self._redis.get(key)
        if not data:
            return None

        try:
            return json.loads(data)
        except json.JSONDecodeError:
            return None

    async def clear(self, event_id: str) -> None:
        """Remove dedup entry (for testing)."""
        key = self._make_key(event_id)
        await self._redis.delete(key)

    async def close(self) -> None:
        """Graceful shutdown."""
        pass

