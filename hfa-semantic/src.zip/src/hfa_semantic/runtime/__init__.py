"""
hfa-semantic/src/hfa_semantic/runtime/__init__.py

IRONCLAD Runtime Foundation — Exports
"""

from .dedup_store import DedupStore
from .eviction import EvictionMetrics, EvictionPolicy, EvictionStrategy
from .inmemory_state_store import InMemoryStateStore
from .partitioning import PartitionStrategy, Partitioner
from .redis_state_store import RedisStateStore
from .runtime_metrics import RuntimeMetrics
from .state_store import RuntimeState, StateStore
from .watermark import LatenessPolicy, Watermark

__all__ = [
    "StateStore",
    "RuntimeState",
    "InMemoryStateStore",
    "RedisStateStore",
    "DedupStore",
    "Watermark",
    "LatenessPolicy",
    "RuntimeMetrics",
    "Partitioner",
    "PartitionStrategy",
    "EvictionPolicy",
    "EvictionStrategy",
    "EvictionMetrics",
]


