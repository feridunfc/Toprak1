"""
hfa-semantic/src/hfa_semantic/runtime/partitioning.py

IRONCLAD Sprint R1 — Partitioning Strategy

Determines how state is keyed and partitioned for scaling.

Strategies:
  * entity_id: one partition per entity
  * tenant_id: one partition per tenant
  * event_type: one partition per event type
  * custom: user-defined partition function

CRITICAL: Prevents state explosion by ensuring bounded partitions per rule.
"""

from enum import Enum
from typing import Callable, Optional


class PartitionStrategy(str, Enum):
    """Partition key strategies."""
    ENTITY_ID = "entity_id"
    TENANT_ID = "tenant_id"
    EVENT_TYPE = "event_type"
    CUSTOM = "custom"


class Partitioner:
    """
    Determines partition key for an event.

    Example:
      partitioner = Partitioner(strategy=PartitionStrategy.TENANT_ID)
      partition = partitioner.partition(event)
      # partition = "tenant:xyz"
    """

    def __init__(
        self,
        strategy: PartitionStrategy = PartitionStrategy.ENTITY_ID,
        custom_fn: Optional[Callable[[dict], str]] = None,
    ):
        self._strategy = strategy
        self._custom_fn = custom_fn

    def partition(self, event: dict) -> str:
        """
        Derive partition key from event.

        Args:
            event: Event dictionary

        Returns:
            Partition key (string)
        """
        if self._strategy == PartitionStrategy.ENTITY_ID:
            entity_id = event.get("entity_id") or event.get("run_id") or "unknown"
            return f"entity:{entity_id}"

        elif self._strategy == PartitionStrategy.TENANT_ID:
            tenant_id = event.get("tenant_id") or "unknown"
            return f"tenant:{tenant_id}"

        elif self._strategy == PartitionStrategy.EVENT_TYPE:
            event_type = event.get("event_type") or "unknown"
            return f"type:{event_type}"

        elif self._strategy == PartitionStrategy.CUSTOM:
            if self._custom_fn is None:
                return "default"
            return self._custom_fn(event)

        else:
            return "default"

    @staticmethod
    def safe_partition(event: dict, strategy: PartitionStrategy) -> str:
        """Convenience method."""
        return Partitioner(strategy=strategy).partition(event)

