"""
hfa-semantic/src/hfa_semantic/runtime/inmemory_state_store.py

IRONCLAD Sprint R1 — In-Memory State Store (Dev/Test Only)

CRITICAL: This is NOT for production.
For testing and development only.

Properties:
  * Fast iteration
  * No durability
  * Single node only
"""

import asyncio
import time
from typing import Any, Dict, Optional

from .state_store import RuntimeState, StateStore


class InMemoryStateStore(StateStore):
    """
    Simple in-memory state store with TTL.

    Use only for development and unit tests.
    """

    def __init__(self, cleanup_interval_ms: int = 5000):
        self._states: Dict[str, Dict[str, RuntimeState]] = {}  # rule_id -> {partition -> state}
        self._lock = asyncio.Lock()
        self._cleanup_interval_ms = cleanup_interval_ms
        self._running = True
        self._cleanup_task: Optional[asyncio.Task] = None

    def _ensure_cleanup_task(self) -> None:
        """Lazily create cleanup task."""
        if self._cleanup_task is None or self._cleanup_task.done():
            try:
                loop = asyncio.get_running_loop()
                self._cleanup_task = loop.create_task(self._periodic_cleanup())
            except RuntimeError:
                # No running loop, cleanup will happen on close
                pass

    async def _periodic_cleanup(self) -> None:
        """Remove expired states periodically."""
        while self._running:
            try:
                await asyncio.sleep(self._cleanup_interval_ms / 1000.0)
                now_ms = time.time() * 1000.0

                async with self._lock:
                    for rule_id in list(self._states.keys()):
                        partitions = self._states[rule_id]
                        for partition in list(partitions.keys()):
                            state = partitions[partition]
                            if state.ttl_ms > 0 and state.last_update_ms + state.ttl_ms < now_ms:
                                del partitions[partition]
                        if not partitions:
                            del self._states[rule_id]
            except asyncio.CancelledError:
                break
            except Exception:
                # Log but continue cleanup
                pass

    async def get(self, rule_id: str, partition: str) -> Optional[RuntimeState]:
        self._ensure_cleanup_task()
        async with self._lock:
            if rule_id not in self._states:
                return None
            if partition not in self._states[rule_id]:
                return None

            state = self._states[rule_id][partition]
            now_ms = time.time() * 1000.0

            # Check expiration
            if state.ttl_ms > 0 and state.last_update_ms + state.ttl_ms < now_ms:
                del self._states[rule_id][partition]
                if not self._states[rule_id]:
                    del self._states[rule_id]
                return None

            return state

    async def put(
        self, rule_id: str, partition: str, state: Dict[str, Any], ttl_ms: int
    ) -> None:
        self._ensure_cleanup_task()
        async with self._lock:
            if rule_id not in self._states:
                self._states[rule_id] = {}

            now_ms = time.time() * 1000.0
            self._states[rule_id][partition] = RuntimeState(
                rule_id=rule_id,
                partition=partition,
                state=state,
                event_count=1,
                last_update_ms=now_ms,
                ttl_ms=ttl_ms,
            )

    async def delete(self, rule_id: str, partition: str) -> None:
        async with self._lock:
            if rule_id in self._states and partition in self._states[rule_id]:
                del self._states[rule_id][partition]
                if not self._states[rule_id]:
                    del self._states[rule_id]

    async def evict(self, rule_id: str, max_partitions: int) -> int:
        """Evict oldest partitions if count exceeds max_partitions."""
        async with self._lock:
            if rule_id not in self._states:
                return 0

            partitions = self._states[rule_id]
            if len(partitions) <= max_partitions:
                return 0

            # Sort by last_update_ms, evict oldest
            sorted_parts = sorted(
                partitions.items(),
                key=lambda x: x[1].last_update_ms,
            )

            to_evict = len(partitions) - max_partitions
            for partition, _ in sorted_parts[:to_evict]:
                del partitions[partition]

            if not partitions:
                del self._states[rule_id]

            return to_evict

    async def list_partitions(self, rule_id: str) -> list[str]:
        async with self._lock:
            if rule_id not in self._states:
                return []
            return list(self._states[rule_id].keys())

    async def close(self) -> None:
        self._running = False
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

