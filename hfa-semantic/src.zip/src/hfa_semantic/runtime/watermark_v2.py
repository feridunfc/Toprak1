"""
hfa-semantic/src/hfa_semantic/runtime/watermark_v2.py

IRONCLAD v6 — Real Streaming Watermark Engine

CRITICAL FIX from v1:
  * Monotonic watermark (never goes backward)
  * Per-rule global tracking
  * Late event handling policy
  * Lua atomic update
"""

import json
import time
from enum import Enum
from typing import Optional

import redis.asyncio as redis

from .lua_scripts import LuaScripts


class LatenessPolicy(str, Enum):
    """Late event handling strategies."""
    DROP = "drop"
    CORRECT = "correct"  # Allow, will retry matching
    SIDE_CHANNEL = "side_channel"  # Route to repair queue


class WatermarkV2:
    """
    Production watermark engine.
    
    Guarantees:
      * Monotonic progression (watermark never decreases)
      * Per-rule global state (Redis backed)
      * Deterministic lateness detection
      * Atomic Lua update
    """

    def __init__(
        self,
        rule_id: str,
        allowed_lateness_ms: int = 10_000,
        redis_client: Optional[redis.Redis] = None,
        namespace: str = "semantic:watermark",
    ):
        self._rule_id = rule_id
        self._allowed_lateness_ms = allowed_lateness_ms
        self._redis = redis_client
        self._namespace = namespace
        
        # Local cache (updated from Redis)
        self._watermark_ms = 0.0
        self._late_count = 0
        self._on_time_count = 0

    def _make_key(self) -> str:
        """Redis key for watermark state."""
        return f"{self._namespace}:{self._rule_id}"

    async def observe(self, event_time_ms: float) -> tuple[bool, bool]:
        """
        Observe event and update watermark (atomic via Lua).
        
        Returns:
            (is_late, should_accept)
            
        is_late: event_time < watermark - allowed_lateness_ms
        should_accept: depends on policy (default DROP late events)
        """
        if not self._redis:
            # Fallback: local-only (non-distributed)
            return self._observe_local(event_time_ms)

        key = self._make_key()
        now_ms = time.time() * 1000.0
        
        # Lua will:
        # 1. Read current watermark
        # 2. Check if event is late
        # 3. Update watermark if on-time
        # 4. Persist
        try:
            is_late_val = await self._redis.eval(
                LuaScripts.WATERMARK_OBSERVE,
                1,  # num keys
                key,
                86400,  # TTL (24h)
                event_time_ms,
                self._allowed_lateness_ms,
                now_ms,
            )
            
            is_late = bool(is_late_val)
            
            # Sync local cache
            await self._sync_from_redis()
            
            return is_late, not is_late
        except Exception:
            # Fallback to local-only
            return self._observe_local(event_time_ms)

    def _observe_local(self, event_time_ms: float) -> tuple[bool, bool]:
        """Fallback local watermark (not distributed)."""
        now_ms = time.time() * 1000.0
        
        if event_time_ms > now_ms:
            event_time_ms = now_ms

        is_late = event_time_ms < self._watermark_ms - self._allowed_lateness_ms

        if is_late:
            self._late_count += 1
        else:
            self._on_time_count += 1
            self._watermark_ms = max(self._watermark_ms, event_time_ms)

        return is_late, not is_late

    async def _sync_from_redis(self) -> None:
        """Load watermark state from Redis."""
        if not self._redis:
            return

        key = self._make_key()
        data = await self._redis.get(key)
        if data:
            try:
                obj = json.loads(data)
                self._watermark_ms = float(obj.get("watermark_ms", 0))
                self._late_count = int(obj.get("late_count", 0))
                self._on_time_count = int(obj.get("on_time_count", 0))
            except (json.JSONDecodeError, ValueError):
                pass

    async def should_accept(
        self,
        event_time_ms: float,
        policy: LatenessPolicy = LatenessPolicy.DROP,
    ) -> bool:
        """
        Determine if event should be accepted based on policy.
        
        Args:
            event_time_ms: Event timestamp
            policy: LatenessPolicy.DROP (default) / CORRECT / SIDE_CHANNEL
            
        Returns:
            True if event should be processed, False if dropped
        """
        is_late, _ = await self.observe(event_time_ms)

        if not is_late:
            return True

        if policy == LatenessPolicy.DROP:
            return False
        elif policy == LatenessPolicy.CORRECT:
            return True
        elif policy == LatenessPolicy.SIDE_CHANNEL:
            return False
        else:
            return False

    @property
    def watermark_ms(self) -> float:
        """Current watermark (event_time)."""
        return self._watermark_ms

    @property
    def late_count(self) -> int:
        return self._late_count

    @property
    def on_time_count(self) -> int:
        return self._on_time_count

    @property
    def late_ratio(self) -> float:
        """Late event ratio for alerting."""
        total = self._late_count + self._on_time_count
        return self._late_count / total if total > 0 else 0.0

    def reset(self) -> None:
        """Reset (for testing only)."""
        self._watermark_ms = 0.0
        self._late_count = 0
        self._on_time_count = 0

