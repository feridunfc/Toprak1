"""
hfa-semantic/src/hfa_semantic/runtime/runtime_metrics.py

IRONCLAD — Production Observability

CRITICAL:
  * Prometheus-compatible metrics
  * Non-blocking instrumentation
  * Real-time visibility into system health

Metrics exposed:
  * events_processed_total: cumulative event count
  * matches_emitted_total: rule firing count
  * state_size_bytes: memory usage estimate
  * eviction_rate: partition eviction pressure
  * dedup_hits_total: duplicate event count
  * late_events_total: ordering anomalies
  * watermark_lag_ms: event ordering lag
"""

from prometheus_client import Counter, Gauge, Histogram


class RuntimeMetrics:
    """Non-blocking Prometheus metrics for semantic runtime."""

    def __init__(self, namespace: str = "semantic"):
        self.namespace = namespace

        # Counters
        self.events_processed = Counter(
            f"{namespace}_events_processed_total",
            "Total events processed by semantic layer",
            ["rule_id"],
        )

        self.matches_emitted = Counter(
            f"{namespace}_matches_emitted_total",
            "Total reasoning matches emitted",
            ["rule_id", "severity"],
        )

        self.dedup_hits = Counter(
            f"{namespace}_dedup_hits_total",
            "Total duplicate events dropped",
        )

        self.late_events = Counter(
            f"{namespace}_late_events_total",
            "Total late events detected",
            ["policy"],
        )

        self.eviction_events = Counter(
            f"{namespace}_eviction_total",
            "Total partition evictions",
            ["rule_id"],
        )

        # Gauges
        self.state_size_estimate = Gauge(
            f"{namespace}_state_size_bytes",
            "Estimated state store size",
            ["rule_id"],
        )

        self.active_partitions = Gauge(
            f"{namespace}_active_partitions",
            "Active partitions per rule",
            ["rule_id"],
        )

        self.watermark_lag = Gauge(
            f"{namespace}_watermark_lag_ms",
            "Lateness lag in milliseconds",
        )

        # Histograms
        self.event_latency = Histogram(
            f"{namespace}_event_latency_ms",
            "Event processing latency",
            ["stage"],
            buckets=(1, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000),
        )

        self.match_confidence = Histogram(
            f"{namespace}_match_confidence",
            "Confidence distribution of emitted matches",
            buckets=(0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.99),
        )

    def record_event_processed(self, rule_id: str) -> None:
        """Record that an event was processed."""
        self.events_processed.labels(rule_id=rule_id).inc()

    def record_match_emitted(self, rule_id: str, severity: str) -> None:
        """Record that a match was emitted."""
        self.matches_emitted.labels(rule_id=rule_id, severity=severity).inc()

    def record_dedup_hit(self) -> None:
        """Record a duplicate event detection."""
        self.dedup_hits.inc()

    def record_late_event(self, policy: str) -> None:
        """Record a late event."""
        self.late_events.labels(policy=policy).inc()

    def record_eviction(self, rule_id: str, count: int) -> None:
        """Record partition eviction."""
        self.eviction_events.labels(rule_id=rule_id).inc(count)

    def set_state_size(self, rule_id: str, size_bytes: int) -> None:
        """Set state size estimate."""
        self.state_size_estimate.labels(rule_id=rule_id).set(size_bytes)

    def set_active_partitions(self, rule_id: str, count: int) -> None:
        """Set active partition count."""
        self.active_partitions.labels(rule_id=rule_id).set(count)

    def set_watermark_lag(self, lag_ms: float) -> None:
        """Set watermark lag."""
        self.watermark_lag.set(lag_ms)

    def record_event_latency(self, stage: str, latency_ms: float) -> None:
        """Record event processing latency for a stage."""
        self.event_latency.labels(stage=stage).observe(latency_ms)

    def record_confidence(self, confidence: float) -> None:
        """Record match confidence score."""
        self.match_confidence.observe(confidence)

