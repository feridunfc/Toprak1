"""
hfa-semantic/src/hfa_semantic/observability/__init__.py

IRONCLAD Observability Layer

Exports runtime metrics and tracing support.
"""

from ..runtime import RuntimeMetrics

__all__ = ["RuntimeMetrics"]

