"""
hfa-semantic/src/hfa_semantic/policy/optimizer_v2.py

Sprint 18 — Cost-Aware Optimizer

Proposes policy changes based on business cost, not just rate-based heuristics.
"""

from __future__ import annotations

from dataclasses import dataclass

from hfa_semantic.memory.semantic_memory_v2 import WeightedOutcome
from hfa_semantic.policy.cost_model import CostModel


@dataclass(slots=True, frozen=True)
class OptimizationContext:
    """Context for policy optimization."""
    current_value: float
    raise_step_abs: float = 2.0
    lower_step_abs: float = 2.0


class CostAwareOptimizer:
    """
    Heuristic optimizer using cost model.
    
    Logic:
      * High false negative cost -> lower threshold (be more sensitive)
      * High false positive cost -> raise threshold (be more strict)
    """

    def propose(
        self,
        context: OptimizationContext,
        outcomes: list[WeightedOutcome],
        cost_model: CostModel,
    ) -> tuple[float, str]:
        """
        Propose threshold change based on cost analysis.
        
        Returns:
            (proposed_value, reason)
        """
        if not outcomes:
            return context.current_value, "no_outcomes"

        # Sum weighted costs per type
        weighted_fp = sum(
            x.weighted_confidence
            for x in outcomes
            if x.outcome.outcome_type.value == "false_positive"
        )
        weighted_fn = sum(
            x.weighted_confidence
            for x in outcomes
            if x.outcome.outcome_type.value == "false_negative"
        )

        # If no errors at all
        if weighted_fp == 0 and weighted_fn == 0:
            return context.current_value, "no_error_signal"

        # Multiply by cost weights
        fp_pressure = weighted_fp * cost_model.false_positive_cost
        fn_pressure = weighted_fn * cost_model.false_negative_cost

        # Decide direction
        if fn_pressure > fp_pressure:
            # False negatives too expensive → lower threshold (more sensitive)
            return (
                context.current_value - context.lower_step_abs,
                "cost_model:false_negative_pressure",
            )

        if fp_pressure > fn_pressure:
            # False positives too expensive → raise threshold (more strict)
            return (
                context.current_value + context.raise_step_abs,
                "cost_model:false_positive_pressure",
            )

        # Balanced
        return context.current_value, "cost_model:balanced"

