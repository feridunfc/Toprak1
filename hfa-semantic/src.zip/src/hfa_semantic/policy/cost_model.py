"""
hfa-semantic/src/hfa_semantic/policy/cost_model.py

Sprint 18 — Cost-Aware Policy Optimization

CRITICAL:
  * Not all errors are equal
  * False negative (missing threat) > false positive (false alarm)
  * Cost function drives optimization
  * Business impact encoded in model
"""

from __future__ import annotations

from dataclasses import dataclass

from hfa_semantic.memory.semantic_memory_v2 import WeightedOutcome


@dataclass(slots=True, frozen=True)
class CostModel:
    """
    Asymmetric cost model for policy optimization.
    
    Business logic:
      * Missing a threat (FN) is very expensive
      * False alarms (FP) are annoying but manageable
      * Failures (infrastructure issues) are costly
      * Successes are rewarded
    """
    
    false_positive_cost: float = 1.0  # Annoying alarm
    false_negative_cost: float = 5.0  # Missed threat (5x worse!)
    failure_cost: float = 2.0  # Infrastructure problem
    success_reward: float = 0.2  # Benefit (reduces cost)

    def score(self, outcomes: list[WeightedOutcome]) -> float:
        """
        Calculate total weighted cost of outcomes.
        
        Returns:
            Total cost (lower is better)
            Negative score = net benefit
        """
        if not outcomes:
            return 0.0
        
        total = 0.0
        for item in outcomes:
            total += self._weighted_cost(item)
        
        return total

    def _weighted_cost(self, item: WeightedOutcome) -> float:
        """Calculate cost for single outcome with decay applied."""
        base = 0.0
        outcome_type = item.outcome.outcome_type

        if outcome_type.value == "false_positive":
            base = self.false_positive_cost
        elif outcome_type.value == "false_negative":
            base = self.false_negative_cost
        elif outcome_type.value == "failure":
            base = self.failure_cost
        elif outcome_type.value == "success":
            base = -self.success_reward  # Negative (reduces cost)
        else:
            base = 0.0

        # Apply decay: older events matter less
        return base * item.weighted_confidence

    def false_positive_expensive_model(self) -> CostModel:
        """Factory: FP-heavy cost (e.g., security context)."""
        return CostModel(
            false_positive_cost=0.5,  # FP is cheap
            false_negative_cost=10.0,  # FN is terrible
            failure_cost=3.0,
            success_reward=0.1,
        )

    def false_negative_acceptable_model(self) -> CostModel:
        """Factory: FN-heavy cost (e.g., performance context)."""
        return CostModel(
            false_positive_cost=2.0,  # FP is annoying
            false_negative_cost=1.0,  # FN is acceptable
            failure_cost=1.0,
            success_reward=0.5,
        )

