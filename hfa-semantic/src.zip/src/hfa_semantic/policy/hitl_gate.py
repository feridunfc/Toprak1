"""
hfa-semantic/src/hfa_semantic/policy/hitl_gate.py

Sprint 16 — Human-In-The-Loop Gate

Large policy changes require human approval.
"""

from __future__ import annotations


def requires_hitl(delta_abs: float, hitl_step_abs: float) -> bool:
    """
    Check if change magnitude requires human review.
    
    CRITICAL: Changes >= hitl_step_abs go to human for approval.
    This prevents silent self-blindness.
    """
    return abs(delta_abs) >= hitl_step_abs

