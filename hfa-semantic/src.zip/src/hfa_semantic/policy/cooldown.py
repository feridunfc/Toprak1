"""
hfa-semantic/src/hfa_semantic/policy/cooldown.py

Sprint 16 — Cooldown Gate

Prevents rapid oscillation in policy values.
"""

from __future__ import annotations


def cooldown_elapsed(
    now_ms: int,
    last_change_ms: int | None,
    cooldown_ms: int,
) -> bool:
    """Check if cooldown period has elapsed."""
    if last_change_ms is None:
        return True  # No prior change
    return (now_ms - last_change_ms) >= cooldown_ms

