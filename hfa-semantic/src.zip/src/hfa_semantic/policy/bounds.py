"""
hfa-semantic/src/hfa_semantic/policy/bounds.py

Sprint 16 — Hard Bounds

Absolute constraints on policy values.
"""

from __future__ import annotations


def within_bounds(value: float, minimum: float, maximum: float) -> bool:
    """Check if value is within bounds."""
    return minimum <= value <= maximum


def clamp(value: float, minimum: float, maximum: float) -> float:
    """Clamp value to bounds."""
    return max(minimum, min(maximum, value))

