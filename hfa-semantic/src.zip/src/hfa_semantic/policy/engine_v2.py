"""
hfa-semantic/src/hfa_semantic/policy/engine_v2.py

Sprint 18 — Policy Engine V2 (Cost-Aware + Closed-Loop)

Main policy decision engine now:
  * Uses cost model (not just rate-based)
  * Generates decision_id for feedback tracking
  * Considers weighted outcomes (with decay)
"""

from __future__ import annotations

from dataclasses import dataclass
from uuid import uuid4

from hfa_semantic.api.models import PolicyDecision
from hfa_semantic.memory.semantic_memory_v2 import SemanticMemoryV2
from hfa_semantic.policy.cost_model import CostModel
from hfa_semantic.policy.hitl_gate import requires_hitl
from hfa_semantic.policy.safety_guard import guard_policy_change
from hfa_semantic.policy.optimizer_v2 import CostAwareOptimizer, OptimizationContext


@dataclass(slots=True, frozen=True)
class PolicyEngineV2Config:
    """Configuration for cost-aware policy engine."""
    
    policy_key: str
    current_value: float
    minimum: float
    maximum: float
    cooldown_ms: int
    
    last_change_ms: int | None = None
    min_sample_size: int = 20
    min_avg_weighted_confidence: float = 0.25
    max_step_abs: float = 5.0
    hitl_step_abs: float = 3.0
    raise_step_abs: float = 2.0
    lower_step_abs: float = 2.0


class PolicyEngineV2:
    """
    Production policy engine with cost awareness and feedback tracking.
    
    CRITICAL:
      * Decisions are first-class entities with unique IDs
      * Cost model drives optimization (not just rates)
      * Decay-weighted outcomes inform decisions
      * Closed-loop feedback enabled via decision_id
    """

    def __init__(
        self,
        cost_model: CostModel | None = None,
        optimizer: CostAwareOptimizer | None = None,
    ) -> None:
        self._cost_model = cost_model or CostModel()
        self._optimizer = optimizer or CostAwareOptimizer()

    def evaluate(
        self,
        config: PolicyEngineV2Config,
        memory: SemanticMemoryV2,
        now_ms: int,
    ) -> PolicyDecision:
        """
        Evaluate if policy should change (cost-aware).
        
        Returns:
            PolicyDecision with decision_id for feedback tracking
        """
        # Get all outcomes with decay weights applied
        weighted = memory.weighted(now_ms)

        # GATE 1: Sufficient outcomes
        if len(weighted) < config.min_sample_size:
            return PolicyDecision(
                decision_id=str(uuid4()),
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=config.current_value,
                approved=False,
                reason="insufficient_weighted_outcomes",
                requires_hitl=False,
                cooldown_applied=False,
            )

        # GATE 2: High enough confidence (decay-weighted)
        avg_weighted_conf = sum(x.weighted_confidence for x in weighted) / len(weighted)
        if avg_weighted_conf < config.min_avg_weighted_confidence:
            return PolicyDecision(
                decision_id=str(uuid4()),
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=config.current_value,
                approved=False,
                reason="weighted_confidence_too_low",
                requires_hitl=False,
                cooldown_applied=False,
            )

        # GATE 3: Cost-aware proposal
        proposed, reason = self._optimizer.propose(
            context=OptimizationContext(
                current_value=config.current_value,
                raise_step_abs=config.raise_step_abs,
                lower_step_abs=config.lower_step_abs,
            ),
            outcomes=weighted,
            cost_model=self._cost_model,
        )

        # No signal
        if proposed == config.current_value:
            return PolicyDecision(
                decision_id=str(uuid4()),
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=proposed,
                approved=False,
                reason=reason,
                requires_hitl=False,
                cooldown_applied=False,
            )

        # GATE 4: Safety guards
        guarded_value, allowed, tags = guard_policy_change(
            proposed_value=proposed,
            current_value=config.current_value,
            minimum=config.minimum,
            maximum=config.maximum,
            now_ms=now_ms,
            last_change_ms=config.last_change_ms,
            cooldown_ms=config.cooldown_ms,
            max_step_abs=config.max_step_abs,
        )

        delta_abs = abs(guarded_value - config.current_value)
        decision_id = str(uuid4())

        if not allowed:
            return PolicyDecision(
                decision_id=decision_id,
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=config.current_value,
                approved=False,
                reason="guard_blocked:" + ",".join(tags),
                requires_hitl=False,
                cooldown_applied="guard:cooldown" in tags,
                tags=tags,
            )

        # GATE 5: HITL for large changes
        if requires_hitl(delta_abs, config.hitl_step_abs):
            return PolicyDecision(
                decision_id=decision_id,
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=guarded_value,
                approved=False,
                reason=reason,
                requires_hitl=True,
                cooldown_applied=False,
                tags=tags + ["requires_human_approval"],
            )

        # All gates passed → approved
        return PolicyDecision(
            decision_id=decision_id,
            policy_key=config.policy_key,
            previous_value=config.current_value,
            proposed_value=guarded_value,
            approved=True,
            reason=reason,
            requires_hitl=False,
            cooldown_applied=False,
            tags=tags,
        )

