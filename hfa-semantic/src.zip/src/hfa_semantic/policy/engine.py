"""
hfa-semantic/src/hfa_semantic/policy/engine.py

Sprint 16 — Policy Engine

Core decision engine for bounded adaptive policy.
"""

from __future__ import annotations

from dataclasses import dataclass
from hfa_semantic.api.models import OutcomeType, PolicyDecision, ValidatedOutcome
from hfa_semantic.policy.hitl_gate import requires_hitl
from hfa_semantic.policy.optimizer import propose_threshold
from hfa_semantic.policy.rules import policy_reason
from hfa_semantic.policy.safety_guard import guard_policy_change


@dataclass(slots=True, frozen=True)
class PolicyEngineConfig:
    """Configuration for policy engine evaluation."""
    
    policy_key: str
    current_value: float
    minimum: float
    maximum: float
    cooldown_ms: int
    
    last_change_ms: int | None = None
    min_sample_size: int = 20
    min_avg_confidence: float = 0.80
    max_step_abs: float = 5.0
    hitl_step_abs: float = 3.0
    raise_step_abs: float = 2.0
    lower_step_abs: float = 2.0


class PolicyEngine:
    """
    Bounded adaptive policy engine.
    
    CRITICAL:
      * Decisions based ONLY on validated outcomes
      * All changes go through safety guards
      * Large changes require human approval (HITL)
      * No runaway adaptation
    """

    def evaluate(
        self,
        config: PolicyEngineConfig,
        outcomes: list[ValidatedOutcome],
        now_ms: int,
    ) -> PolicyDecision:
        """
        Evaluate if policy should change.
        
        Returns:
            PolicyDecision (approved or reason for rejection)
        """
        # GATE 1: Sufficient validated samples
        validated = [o for o in outcomes if o.validated]

        if len(validated) < config.min_sample_size:
            return PolicyDecision(
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=config.current_value,
                approved=False,
                reason="insufficient_validated_outcomes",
                requires_hitl=False,
                cooldown_applied=False,
            )

        # GATE 2: High confidence in outcomes
        avg_conf = sum(o.confidence for o in validated) / len(validated)
        if avg_conf < config.min_avg_confidence:
            return PolicyDecision(
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=config.current_value,
                approved=False,
                reason="validated_outcomes_confidence_too_low",
                requires_hitl=False,
                cooldown_applied=False,
            )

        # GATE 3: Analyze false positive / negative rates
        fp_rate = sum(
            1 for o in validated if o.outcome_type == OutcomeType.FALSE_POSITIVE
        ) / len(validated)
        fn_rate = sum(
            1 for o in validated if o.outcome_type == OutcomeType.FALSE_NEGATIVE
        ) / len(validated)

        # GATE 4: Propose change
        proposed = propose_threshold(
            current_value=config.current_value,
            false_positive_rate=fp_rate,
            false_negative_rate=fn_rate,
            raise_step_abs=config.raise_step_abs,
            lower_step_abs=config.lower_step_abs,
        )

        reason = policy_reason(fp_rate, fn_rate)
        if proposed == config.current_value:
            return PolicyDecision(
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=proposed,
                approved=False,
                reason=reason,
                requires_hitl=False,
                cooldown_applied=False,
            )

        # GATE 5: Apply safety guards
        guarded_value, allowed, guard_tags = guard_policy_change(
            proposed_value=proposed,
            current_value=config.current_value,
            minimum=config.minimum,
            maximum=config.maximum,
            now_ms=now_ms,
            last_change_ms=config.last_change_ms,
            cooldown_ms=config.cooldown_ms,
            max_step_abs=config.max_step_abs,
        )

        if not allowed:
            return PolicyDecision(
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=config.current_value,
                approved=False,
                reason="guard_blocked",
                requires_hitl=False,
                cooldown_applied="guard:cooldown_active" in guard_tags,
                tags=guard_tags,
            )

        # GATE 6: Check if HITL required
        delta_abs = abs(guarded_value - config.current_value)
        hitl = requires_hitl(delta_abs, config.hitl_step_abs)

        if hitl:
            return PolicyDecision(
                policy_key=config.policy_key,
                previous_value=config.current_value,
                proposed_value=guarded_value,
                approved=False,
                reason=reason,
                requires_hitl=True,
                cooldown_applied=False,
                tags=guard_tags + ["requires_human_approval"],
            )

        # All guards passed, approved
        return PolicyDecision(
            policy_key=config.policy_key,
            previous_value=config.current_value,
            proposed_value=guarded_value,
            approved=True,
            reason=reason,
            requires_hitl=False,
            cooldown_applied=False,
            tags=guard_tags,
        )

